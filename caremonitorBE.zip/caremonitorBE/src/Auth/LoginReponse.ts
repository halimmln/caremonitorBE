
export type LoginResponse = {
  tokens: {
    accessToken: string;
    refreshToken: string;
  };
  userDetails: any ;
};
