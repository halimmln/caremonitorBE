import { Kysely } from "kysely";
import { DB } from "../db/db";
import { UUID } from "crypto";
import logger from "../core/Logger";
import { Token } from "./Token";
import { NewToken } from "./Token";

export class AdminTokenRepo {
  public static inject = ["db"] as const;
  constructor(private db: Kysely<DB>) {}

  async saveToken(newToken: NewToken): Promise<void> {
    await this.db.insertInto("token").values(newToken).execute();
    const { type, userId, id: tokenId } = newToken;
    logger.debug(`Inserted`, { type, userId, tokenId });
  }

  async findTokensByUserId(userId: string): Promise<Token[]> {
    const tokens = await this.db
      .selectFrom("token")
      .select(["id", "type", "expiry", "userId"])
      .where("userId", "=", userId)
      .execute();
    return tokens.map((data) => Token.new(data));
  }

  async findById(tokenId: UUID): Promise<Token | undefined> {
    const tokenData = await this.db
      .selectFrom("token")
      .select(["id", "type", "expiry", "userId"])
      .where("id", "=", tokenId)
      .executeTakeFirst();
    return tokenData ? Token.new(tokenData) : undefined;
  }

  async deleteToken(tokenId: UUID): Promise<void> {
    await this.db.deleteFrom("token").where("id", "=", tokenId).execute();
  }
}
