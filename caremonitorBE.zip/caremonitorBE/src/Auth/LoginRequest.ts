import { JoiBasedValidator } from "../core/BaseValidator";
import joi from "../core/JoiExtensions";

export class LoginRequest {
  public readonly userId: string;
  public readonly password: string;
  
  constructor(obj: Readonly<LoginRequest>) {
    this.userId = obj.userId;
    this.password = obj.password;
    
  }

  public static async of(obj: Readonly<LoginRequest>): Promise<LoginRequest> {
    await LoginRequest.validator.validate(obj);
    return new LoginRequest(obj);
  }

  private static schema = joi.object<LoginRequest>({
    userId: joi.string().required(),
    password: joi.password().required(),
  });

  private static validator = new JoiBasedValidator<LoginRequest>(
    LoginRequest.schema,
  );
}
