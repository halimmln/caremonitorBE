import { Request, Response } from "express";
import { Request as JWTRequest } from "express-jwt";
import { SuccessResponse, SuccessMsgResponse } from "../core/ApiResponse";
import { AuthService } from "./AuthService";
import { BadTokenError } from "../core/ApiError";
import { UUID } from "crypto";
import { LoginRequest } from "./LoginRequest";

export class AuthController {
  constructor(
    private authService: AuthService,
  ) {}

  public static inject = ["authService"] as const;

  async login(req: Request, res: Response): Promise<void> {
    const loginRequest = await LoginRequest.of(req.body);
    const loginResponse = await this.authService.login(loginRequest);
    new SuccessResponse("User", loginResponse).send(res);
  }

  async logout(_req: JWTRequest, res: Response): Promise<void> {
    const userId = _req.auth?.sub as UUID;
    const bankId = _req.body.bankId as UUID;
    if (!userId) throw new BadTokenError();
    await this.authService.logout(userId, bankId);
    const response = new SuccessMsgResponse("Logged out successfully");
    response.send(res);
  }
  async refresh(req: Request, res: Response): Promise<void> {
    const refreshToken = req.body.refreshToken as UUID;
   
      const accessToken =
        await this.authService.refreshAuthTokenOfAdmin(refreshToken);
      const response = new SuccessResponse("Reissued a token", accessToken);
      response.send(res);
    
  }
}
