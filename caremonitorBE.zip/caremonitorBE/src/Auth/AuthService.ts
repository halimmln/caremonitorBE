import { LoginResponse } from "./LoginReponse";
import { LoginRequest } from "./LoginRequest";
import { Request } from "express-jwt";
import { BadRequestError, BadTokenError, NoEntryError } from "../core/ApiError";
import bcrypt from "bcrypt";
import {
  accessTokenExpiry,
  refreshTokenExpiry,
  jwtPrivateKey,
  bankAdminPasswordResetTokenExpiry
} from "../config";
import jwt from "jsonwebtoken";
import { AdminTokenRepo } from "./AdminTokenRepo";
import { TokenType } from "./Token";
import { UUID, randomUUID } from "crypto";
import { AdminUserRepo } from "../Item/AdminUserRepo";
import { Role } from "./Role";
export class AuthService {
  public static inject = [
    "adminTokenRepo",
    "adminUserRepo",
  ] as const;
  private readonly tokenExpiryInSec = {
    access: accessTokenExpiry / 1000,
    refresh: refreshTokenExpiry / 1000,
    bankAdmPswdRset: bankAdminPasswordResetTokenExpiry / 1000
  };

  constructor(
    private adminTokenRepo: AdminTokenRepo,
    private adminUserRepo: AdminUserRepo,
  ) {}

  public async login({
    userId,
    password,
    
  }: LoginRequest): Promise<LoginResponse> {
    const userCreds = await this.findByUserId(userId);
    let institutionName = null;
    let bankLogo = "";

    const { encryptedPassword, ...userDetails } = userCreds!;
    await this.validatePassword(password, encryptedPassword);
    const accessToken = await this.generateAccessToken(userCreds!);
    const refreshToken = await this.generateRefreshToken(userCreds!);
    return {
      tokens: {
        accessToken: accessToken,
        refreshToken: refreshToken
      },
      userDetails: {
        ...userDetails,
        
      }
    };
  }

  async logout(userId: UUID, bankId?: UUID): Promise<void> {
    for (const token of await this.adminTokenRepo.findTokensByUserId(userId)) {
      await this.adminTokenRepo.deleteToken(token.id);
    }
  }

  

  async refreshAuthTokenOfAdmin(
    refreshTokenId: UUID
  ): Promise<{ accessToken: string }> {
    const refreshToken = await this.adminTokenRepo.findById(refreshTokenId);

    if (!refreshToken || refreshToken.type != TokenType.refreshToken) {
      throw new BadTokenError();
    }

    if (refreshToken.isExpired()) {
      await this.adminTokenRepo.deleteToken(refreshTokenId);
      throw new BadTokenError();
    }

    const user = (await this.adminUserRepo.findUserById(refreshToken.userId))!;
    const accessToken = await this.generateAccessToken(user);
    return { accessToken };
  }

  private async generateRefreshToken({ id: userId }: any) {
    const expiresIn = this.tokenExpiryInSec.refresh;
    const jwtid = randomUUID();
    const expiry = new Date().getTime() + expiresIn * 1000;

    await this.adminTokenRepo.saveToken({
      id: jwtid,
      userId: userId,
      expiry: expiry,
      type: TokenType.refreshToken
    });
    return jwtid;
  }

  private signToken(payload: object = {}, options: jwt.SignOptions) {
    return jwt.sign(payload, `${jwtPrivateKey}`, options);
  }

  private async generateAccessToken({
    role,
    id: userId,
    firstName,
    lastName
  }: any): Promise<string> {
    const expiresIn = this.tokenExpiryInSec.access;
    const jwtid = randomUUID();
    const expiry = new Date().getTime() + expiresIn * 1000;

    const token = this.signToken(
      { role, userName: `${firstName} ${lastName}` },
      { subject: userId, expiresIn, jwtid }
    );

    await this.adminTokenRepo.saveToken({
      id: jwtid,
      userId: userId,
      expiry: expiry,
      type: TokenType.accessToken
    });
    return token;
  }

  private async validatePassword(password: string, encryptedPassword: string) {
    const isPasswordMatch = await bcrypt.compare(password, encryptedPassword);
    if (!isPasswordMatch) {
      throw BadRequestError.of([
        { message: "Invalid credintials", path: [""] }
      ]);
    }
  }


  private async findByUserId(userId: string) {
    const userCreds = (await this.adminUserRepo.findUserByUserId(userId)).at(0);
    if (!userCreds) {
      throw new NoEntryError();
    }
    return userCreds;
  }
}

export type Auth = jwt.JwtPayload & any;

export function restrictedQuery<T>(req: Request<Auth>): T {
  if (!req.auth || req.auth.role === Role.systemAdmin) return req.query as T;
  return { ...req.query, } as T;
}
