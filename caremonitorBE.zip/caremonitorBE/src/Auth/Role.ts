export enum Role {
  systemAdmin = "system_admin",
  applicant = "applicant",
  
}
