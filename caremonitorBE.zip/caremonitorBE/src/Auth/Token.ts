import { UUID } from "crypto";

export class Token {
  public id: UUID;
  public type: TokenType;
  public expiry: number;
  public userId: UUID;

  private constructor(state: TokenState) {
    this.id = state.id;
    this.type = state.type;
    this.expiry = state.expiry;
    this.userId = state.userId;
  }

  static new(data: {
    id: string;
    type: string;
    expiry: string;
    userId: string;
  }): Token {
    const id = data.id as UUID;
    const type = data.type as TokenType;
    const expiry = +data.expiry;
    const userId = data.userId as UUID;

    return new Token({ id, type, expiry, userId });
  }

  isExpired(): boolean {
    const now = new Date().getTime();
    return this.expiry < now;
  }
}
export type TokenState = Omit<Readonly<Token>, "isExpired">;
export enum TokenType {
  accessToken = "access_token",
  refreshToken = "refresh_token",
}
export type NewToken = Readonly<{
  id: UUID;
  type: TokenType;
  expiry: number;
  userId: UUID;
}>;
