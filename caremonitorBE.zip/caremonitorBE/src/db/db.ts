import type { ColumnType } from "kysely";

export type Generated<T> = T extends ColumnType<infer S, infer I, infer U>
  ? ColumnType<S, I | undefined, U>
  : ColumnType<T, T | undefined, T>;

export type Int8 = ColumnType<string, bigint | number | string, bigint | number | string>;

export type Timestamp = ColumnType<Date, Date | string, Date | string>;

export interface AppUser {
  address: string | null;
  contactNumber: string;
  createdAt: Generated<Timestamp>;
  email: string;
  firstName: string;
  id: string;
  lastName: string;
  password: string;
  role: string;
  status: string | null;
  updatedAt: Generated<Timestamp>;
  userId: string | null;
}

export interface Token {
  createdAt: Generated<Timestamp>;
  expiry: Int8;
  id: string;
  type: string;
  updatedAt: Generated<Timestamp>;
  userId: string;
}

export interface User {
  address: string;
  createdAt: Generated<Timestamp>;
  id: string;
  name: string;
  type: string;
  updatedAt: Generated<Timestamp>;
}

export interface DB {
  appUser: AppUser;
  token: Token;
  user: User;
}
