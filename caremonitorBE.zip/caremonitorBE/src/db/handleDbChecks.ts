import { log } from "console";
import { BadRequestError } from "../core/ApiError";
export type DbChecks = {
  [constraint: string]: { path: [string]; message: string };
};
export type DbCheckHandler = <T>(block: () => Promise<T>) => Promise<T>;
export const handleDbChecks =
  <T>(dbChecks: DbChecks) =>
  async (block: () => Promise<T>): Promise<T> => {
    try {
      return await block();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (error: any) {
      log("error+++++++++++++++", error);
      if (error.constraint)
        throw BadRequestError.of([dbChecks[error.constraint]!]);
      throw error;
    }
  };
