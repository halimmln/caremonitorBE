/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { Kysely, sql } from "kysely";

export async function up(db: Kysely<unknown>): Promise<void> {
  db.schema
    .createTable("token")
    .addColumn("id", "uuid", (col) => col.primaryKey())
    .addColumn("type", "varchar(255)", (col) => col.notNull())
    .addColumn("expiry", "bigint", (col) => col.notNull())
    .addColumn("user_id", "uuid", (col) =>
      col.notNull().references("app_user.id").onDelete("cascade"),
    )
    .addColumn("created_at", "timestamptz", (col) =>
      col.defaultTo(sql`now()`).notNull(),
    )
    .addColumn("updated_at", "timestamptz", (col) =>
      col.defaultTo(sql`now()`).notNull(),
    )
    .execute();

  await db.schema
    .createIndex("token_type_user_index")
    .on("token")
    .columns(["id", "type", "user_id"])
    .execute();
}

export async function down(db: Kysely<unknown>): Promise<void> {
  await db.schema.dropTable("token").execute();
}
