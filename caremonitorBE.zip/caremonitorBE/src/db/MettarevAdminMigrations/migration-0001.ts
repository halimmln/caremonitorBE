import { Kysely, sql } from "kysely";

export async function up(db: Kysely<unknown>): Promise<void> {
  await db.schema
    .createTable("app_user")
    .addColumn("id", "uuid", (col) => col.primaryKey())
    .addColumn("first_name", "varchar(256)", (col) => col.notNull())
    .addColumn("last_name", "varchar(256)", (col) => col.notNull())
    .addColumn("email", "varchar(256)", (col) => col.notNull())
    .addColumn("password", "varchar(256)", (col) => col.notNull())
    .addColumn("contact_number", "varchar(15)", (col) => col.notNull().unique())
    .addColumn("role", "varchar(15)", (col) => col.notNull())
    .addColumn("address", "varchar(512)")
    .addColumn("status", "varchar(512)")
    .addColumn("user_id", "varchar(512)")
    
    .addColumn("created_at", "timestamptz", (col) =>
      col.defaultTo(sql`now()`).notNull(),
    )
    .addColumn("updated_at", "timestamptz", (col) =>
      col.defaultTo(sql`now()`).notNull(),
    )
    .execute();

  
}

export async function down(db: Kysely<unknown>): Promise<void> {
  await db.schema.dropTable("app_user").execute();
}
