/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { Kysely } from "kysely";

export async function up(db: Kysely<any>): Promise<void> {
  db.insertInto("app_user")
    .values({
      id: "35a8b9f2-96c1-4503-866c-417b05fcbde5",
      first_name: "care",
      last_name: "Admin",
      email: "halimmln0@gmail.com",
      password: "$2a$12$7BlJgTCnILbBqMsTKU6g2OTDcIkE8ZQDqGTLGWIlSw8YejGddxFUK",
      contact_number: "+918552076726",
      role: "system_admin",
      user_id:"CareMonitor"
    })
    .execute();
}

export async function down(db: Kysely<any>): Promise<void> {
  db.deleteFrom("app_user")
    .where("id", "=", "35a8b9f2-96c1-4503-866c-417b05fcbde5")
    .execute();
}
