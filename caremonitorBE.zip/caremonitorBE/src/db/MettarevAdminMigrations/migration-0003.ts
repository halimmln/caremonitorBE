import { Kysely, sql } from "kysely";

export async function up(db: Kysely<unknown>): Promise<void> {
  await db.schema
    .createTable("user")
    .addColumn("id", "uuid", (col) => col.primaryKey())
    .addColumn("name", "varchar(512)", (col) => col.notNull())
    .addColumn("address", "varchar(512)", (col) => col.notNull())
    .addColumn("type", "varchar(100)", (col) => col.notNull())
    .addColumn("created_at", "timestamptz", (col) =>
      col.defaultTo(sql`now()`).notNull(),
    )
    .addColumn("updated_at", "timestamptz", (col) =>
      col.defaultTo(sql`now()`).notNull(),
    )
    // Add unique constraint on the bank_domain_name column
    
    .execute();
}

export async function down(db: Kysely<unknown>): Promise<void> {

  await db.schema.dropTable("user").execute();
}
