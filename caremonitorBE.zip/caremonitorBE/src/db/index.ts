import { Pool } from "pg";
import { promises as fs } from "fs";
import {
  Kysely,
  Migrator,
  PostgresDialect,
  FileMigrationProvider,
} from "kysely";
import path from "path";
import logger from "../core/Logger";
import { environment } from "../config";
export type DbConfig = {
  database: string;
  host: string;
  user: string;
  password: string;
  port: number;
};
export function database(dbConfig: DbConfig | undefined): Kysely<unknown> {
  const config = dbConfig || {
    database: process.env.DB_NAME!,
    host: process.env.DB_HOST!,
    user: process.env.DB_USER!,
    password: process.env.DB_PASSWORD!,
    port: +process.env.DB_PORT!,
  };
  return new Kysely<unknown>({
    dialect: new PostgresDialect({ pool: new Pool(config) }),
  });
}
function initMigrator(db: Kysely<unknown>) {
  return new Migrator({
    db,
    provider: new FileMigrationProvider({
      fs,
      path,
      // This needs to be an absolute path.
      migrationFolder: path.join(__dirname, "MettarevAdminMigrations"),
    }),
  });
}

export async function migrateToLatest(
  dbConfig: DbConfig | undefined,
): Promise<void> {
  const db = database(dbConfig);
  const migrator = initMigrator(db);

  const migrations = await migrator.getMigrations();
  
  const migrationsYetToApply = migrations.filter(
    (m) => m.executedAt == undefined,
  ).length;

  if (migrationsYetToApply > 0) {
    logger.info(
      `🔄 applying ${migrationsYetToApply} migration on ${environment}`,
    );
    const { error, results } = await migrator.migrateToLatest();

    results?.forEach((it) => {
      const direction = `direction(${it.direction == "Up" ? "🔺" : "🔻"})`;
      const status =
        it.status == "Success" ? "✅" : it.status == "Error" ? "❌" : "⏸️";
      const msg = `${it.migrationName} executed in ${direction} ${status}`;
      if (it.status === "Success") logger.debug(`${msg}`);
      else if (it.status === "Error") logger.error(`${msg}`);
    });

    if (error) {
      console.error("failed to migrate");
      console.error(error);
      process.exit(1);
    } else {
      logger.info(
        `✅ ${results?.length} migrations applied successfully on ${environment}`,
      );
    }
  }

  await db.destroy();
}
