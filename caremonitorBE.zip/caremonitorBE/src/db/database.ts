import { Pool } from "pg";
import { CamelCasePlugin, Kysely, PostgresDialect } from "kysely";
import { DB } from "./db";
import { DbConfig } from ".";

const dialect = (dbConfig: DbConfig) =>
  new PostgresDialect({
    pool: new Pool({
      ...dbConfig,
      max: 10,
    }),
  });

// Database interface is passed to Kysely's constructor, and from now on, Kysely
// knows your database structure.
// Dialect is passed to Kysely's constructor, and from now on, Kysely knows how
// to communicate with your database.

export function kyselyDb(dbConfig: DbConfig): Kysely<DB> {
  return new Kysely<DB>({
    dialect: dialect(dbConfig),
    plugins: [new CamelCasePlugin()],
  });
}
