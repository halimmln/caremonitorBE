import { Request } from "express-jwt";
import { Response } from "express";
import { randomUUID } from "crypto";
import { SuccessResponse } from "../core/ApiResponse";
import { Item } from "./Types";
import { NewItemsRequest } from "./ItemContarct";
import { ItemRepo } from "./ItemRepo";
import { Auth } from "../Auth/AuthService";

import console = require("console");

export class ItemController {
         public static inject = ["itemRepo"] as const;
         constructor(private itemRepo: ItemRepo) {}

         async getAllItems(_req: Request, res: Response): Promise<void> {
           try {
             const items = await this.itemRepo.findAllItem();
             

             const msg = new SuccessResponse("found items", items);
             msg.send(res);
           } catch (error) {
             console.error("Error fetching items or logos:", error);
             res.status(500).send({ error: "Failed to fetch items or logos" });
           }
         }

         async createItem(req: Request<Auth>, res: Response): Promise<void> {
          

           const reqest = {
             ...req.body
           };
           const newItemReq = await NewItemsRequest.of(reqest);
           const { ...ItemData } = newItemReq;
           const newItem: Item = {
             ...ItemData,
             id: randomUUID()
           };

           await this.itemRepo.newItem(newItem);

           const response = new SuccessResponse("Item", newItem);

           response.send(res);
         }
       }
