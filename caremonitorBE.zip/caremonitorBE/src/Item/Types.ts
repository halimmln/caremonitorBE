
import { NewItemsRequest } from "./ItemContarct";
import { UUID } from "crypto";

type Id = { id: UUID };
export type Item = NewItemsRequest & Id;


export type ItemAdminDetails = Id & {
  userId: string | null;
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  contactNumber: string;
  status: string;
};
