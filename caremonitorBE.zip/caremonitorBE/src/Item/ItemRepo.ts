import { Kysely } from "kysely";
import { Item } from "./Types";
import { DbCheckHandler, handleDbChecks } from "../db/handleDbChecks";
import { DB } from "../db/db";
export class ItemRepo {
         private readonly db: Kysely<DB>;
         public static inject = ["db"] as const;
         constructor(db: Kysely<DB>) {
           this.db = db;
         }
         async newItem(item: Item): Promise<bigint | undefined> {
           const itemData = { ...item };
           const query = this.db.insertInto("user").values(itemData);
           const newItem = await handleItemDbChecks(() => query.execute());
           return newItem.at(0)?.numInsertedOrUpdatedRows;
         }

         async findItemById(id: string): Promise<Item | undefined> {
           const result = await this.db
             .selectFrom("user")
             .where("id", "=", id)
             .select(["id", "name", "type", "address"])
             .execute();
           const item = result.at(0);
           return item != undefined ? ((item as unknown) as Item) : undefined;
         }

         async findAllItem(): Promise<Item[]> {
           return ((await this.db
             .selectFrom("user")
             .select(["id", "name", "type", "address"])
             .execute()) as unknown) as Item[];
         }
       }

const handleItemDbChecks: DbCheckHandler = handleDbChecks({});
