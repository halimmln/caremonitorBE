import {
  Kysely,
} from "kysely";
import { AppUser, DB } from "../db/db";
import { Role } from "../Auth/Role";
import bcrypt from "bcrypt";
import { UUID } from "crypto";
import logger from "../core/Logger";
import { DbCheckHandler, handleDbChecks } from "../db/handleDbChecks";
import { NotFoundError } from "../core/ApiError";

export type UserFilter = Partial<Pick<AppUser, | "contactNumber">>;
export class AdminUserRepo {
  public static inject = ["db"] as const;
  constructor(private db: Kysely<DB>) {}

  async findUserByEmail(email: string): Promise<any[]> {
    const result = await this.db
      .selectFrom("appUser")
      .select([
        "id",
        "userId",
        "role",
        "email",
        "password",
        "firstName",
        "lastName",
      ])
      .where("email", "=", email)
      .execute();
    return result.map(
      ({
        id,
        userId,
        email,
        password: encryptedPassword,
        role,
        firstName,
        lastName,
      }) => ({
        id: id as UUID,
        email,
        userId,
        encryptedPassword,
        role: role as Role,
        firstName,
        lastName,
      }),
    );
  }

  async findUserByUserId(userId: string): Promise<any[]> {
    const result = await this.db
      .selectFrom("appUser")
      .select([
        "id",
        "userId",
        "role",
        "email",
        "password",
        "firstName",
        "lastName",
      ])
      .where("userId", "=", userId)
      .execute();
    return result.map(
      ({
        id,
        userId,
        email,
        password: encryptedPassword,
        role,
        firstName,
        lastName,
      }) => ({
        id: id as UUID,
        email,
        userId,
        encryptedPassword,
        role: role as Role,
        firstName,
        lastName,
      }),
    );
  }

  async findUserById(id: string): Promise<any | undefined> {
    const result = await this.db
      .selectFrom("appUser")
      .select([
        "id",
        "firstName",
        "lastName",
        "role",
        "email",
        "contactNumber",
        "address",
      ])
      .where("id", "=", id)
      .execute();

    return result.at(0) as any;
  }

  async changePassword(userId: UUID, newPassword: string): Promise<void> {
    const query = this.db
      .updateTable("appUser")
      .set({
        password: await bcrypt.hash(newPassword, 12),
        updatedAt: new Date(),
      })
      .where("id", "=", userId);

    await handleUserDbChecks(async () => {
      const result = await query.executeTakeFirst();
      logger.info(`Updated User`, {
        userId,
        numUpdatedRows: result.numUpdatedRows,
      });
    });
  }

  async validatePassword(userId: UUID, oldPassword: string): Promise<boolean> {
    const fromDB = await this.db
      .selectFrom("appUser")
      .select("password")
      .where("id", "=", userId)
      .executeTakeFirst();
    if (!fromDB) throw new NotFoundError(`Not found ${userId}`);
    const isMatched = await bcrypt.compare(oldPassword, fromDB.password);
    return isMatched;
  }
}

const handleUserDbChecks: DbCheckHandler = handleDbChecks({
  
});
