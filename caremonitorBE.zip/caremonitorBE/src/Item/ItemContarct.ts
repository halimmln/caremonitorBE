import { JoiBasedValidator } from "../core/BaseValidator";
import joi from "../core/JoiExtensions";

export class NewItemsRequest {
         public readonly address: string;
         public readonly name: string;
         public readonly type: string;

         constructor(obj: { address: string; name: string; type: string }) {
           this.address = obj.address;
           this.name = obj.name;
           this.type = obj.type;
         }

         public static async of(
           req: Readonly<NewItemsRequest>
         ): Promise<NewItemsRequest> {
           await NewItemsRequest.validator.validate({
             address: req.address,
             name: req.name,
             type: req.type
           });

           // Create and return a new instance of NewItemsRequest
           return new NewItemsRequest({
             address: req.address,
             name: req.name,
             type: req.type
           });
         }

         private static schema = joi.object<{
           address: string;
           name: string;
           type: string;
         }>({
           address: joi.string().required(),
           name: joi.string().required(),
           type: joi.string().required()
         });

         private static validator = new JoiBasedValidator<{
           address: string;
           name: string;
           type: string;
         }>(NewItemsRequest.schema);
       }
