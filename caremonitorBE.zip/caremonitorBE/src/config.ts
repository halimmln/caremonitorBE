import ms from "ms";
export const environment = process.env.NODE_ENV;
export const port = process.env.PORT;
export const timezone = process.env.TZ;

export const logDirectory = process.env.LOG_DIR;

export const dbUser = process.env.DB_USER!;
export const dbPassword = process.env.DB_PASSWORD!;
export const dbHost = process.env.DB_HOST!;
export const dbPort = +process.env.DB_PORT!;
export const dbName = process.env.DB_NAME!;
export const dbURL = process.env.DB_URL;

export const jwtPrivateKey = process.env.JWT_SECRET!;
export const accessTokenExpiry = ms(
  process.env.ACCESS_TOKEN_EXPIRES_IN! || "1h",
);
export const refreshTokenExpiry = ms(
  process.env.REFRESH_TOKEN_EXPIRES_IN! || "12h",
);
export const bankAdminPasswordResetTokenExpiry = ms(
  process.env.BANK_ADMIN_PASSWORD_RESET_TOKEN_EXPIRES_IN! || "24h",
);

// ScoreMe
export const scopreMeClientId = process.env.SM_CLIENT_ID!;
export const scopreMeClientSecret = process.env.SM_CLIENT_SECRET!;
// Sure pass
export const surePassApiToken = process.env.SP_API_TOKEN!;
export const surePassApi = process.env.SP_API_URL!;
// AWS.S3
export const fileBucket = process.env.S3_BUCKET!;
export const s3ClientConfig = {
  region: "ap-south-1",
  credentials:
    environment === "local"
      ? {
          accessKeyId: process.env.S3_ACCESS_ID!,
          secretAccessKey: process.env.S3_ACCESS_KEY!,
        }
      : undefined,
};

export const finvuApi = process.env.FINVU_API_URL!;
export const finvuUserId = process.env.FINVU_USER_ID!;
export const finvuPassword = process.env.FINVU_PASSWORD!;
export const finvuRid = process.env.FINVU_RID!;
export const sqsConfig = {
  region: "ap-south-1",
  credentials: {
    accessKeyId: process.env.SQS_ACCESS_ID!,
    secretAccessKey: process.env.SQS_ACCESS_KEY!,
  },
};
export const sqsInputUrl = process.env.SQS_INPUT_URL!;
export const sqsOutputUrl = process.env.SQS_OUTPUT_URL!;

export const smtpHost = process.env.AWS_SES_HOST!;
export const smtpPort = process.env.AWS_SES_PORT!;
export const smtpUser = process.env.AWS_SES_USER!;
export const smtpPass = process.env.AWS_SES_PASS!;
export const adminEmail = process.env.AWS_SES_ADMIN_EMAIL!;
export const ENCRYPTION_KEY =
  process.env.ENCRYPTION_KEY! ||
  "6cd370fe2a4addb722900b57b01eb4a693124356a1ede85dc126296ba159bc1f";
export const ENCRYPTION_IV =
  process.env.ENCRYPTION_IV! || "69080fa1af9fa0ae44a245e19686fb3b";
export const kmsConfig = {
  region: "ap-south-1",
  credentials: {
    accessKeyId: process.env.KMS_ACCESS_ID!,
    secretAccessKey: process.env.KMS_ACCESS_KEY!,
  },
};
/* eslint-disable @typescript-eslint/naming-convention */
export const keyPolicy = {
  Version: "2012-10-17",
  Statement: [
    {
      Sid: "dev_testing_kms",
      Effect: "Allow",
      Principal: {
        AWS: "USER_ARN",
      },
      Action: [
        "kms:Encrypt",
        "kms:Decrypt",
        "kms:DescribeKey",
        "kms:GenerateDataKey",
        "kms:CreateAlias",
      ],
      Resource: "*",
    },
    {
      Sid: "AllowRootAccountToManageKeyPolicy",
      Effect: "Allow",
      Principal: {
        AWS: "USER_ARN",
      },
      Action: "kms:PutKeyPolicy",
      Resource: "*",
    },
    {
      Sid: "EnableKeyManagement",
      Effect: "Allow",
      Principal: { AWS: "ROOT_ARN" },
      Action: "kms:*",
      Resource: "*",
    },
  ],
};
export const emailTemplates = {
  passwordReset: `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
      </style>
    </head>
    <body>
      <div>
        <p>Hello,</p>
        <p>We have received a request to set your password. Click the link below:</p>
        <a href="{{RESET_LINK}}">Reset Password</a>
        <p>After setting your password, you will be automatically redirected to the login page.</p>
        <p>You can also log in directly using the following link after setting your password.</p>
        <a href="{{LOGIN_LINK}}">Login Link</a>

        <p>If you did not request this, please ignore this email.</p>

        <p>Regards,<br>Mettarev Admin</p>
      </div>
    </body>
    </html>
  `,
};
