import { Request, Response, NextFunction } from "express";

export type AsyncFunction<T> = (
  req: Request,
  res: Response,
  next: NextFunction,
) => Promise<T>;

export const asyncHandler =
  <T>(execution: AsyncFunction<T>) =>
  (req: Request, res: Response, next: NextFunction): void => {
    execution(req, res, next).catch(next);
  };

export function parseEnum<T>(
  enumType: Record<string, T>,
  value: string | undefined,
): T | undefined {
  const inputAsEnum = value as T;
  return Object.values(enumType).includes(inputAsEnum)
    ? (value as T)
    : undefined;
}
