export interface Validator<T> {
  validate(obj: T): Promise<T>;
}

export type ValidationError = {
  message: string;
  path: string[];
};
