import Joi, { StringSchema } from "joi";

// Define a custom Joi extension for validating contact numbers
const contactNumberExtension = {
  type: "contactNumber",
  base: Joi.string()
    .pattern(/^[0-9]+$/)
    .min(7)
    .max(13)
    .messages({
      // eslint-disable-next-line @typescript-eslint/naming-convention
      "string.pattern.base": "{{#label}} must contain only digits",
    }),
};

// Define a custom Joi extension for validating emails
const emailExtension = {
  type: "email",
  base: Joi.string().email({ minDomainSegments: 2 }).messages({
    // eslint-disable-next-line @typescript-eslint/naming-convention
    "string.email": "{{#label}} must be a valid email",
  }),
};

// Define a custom Joi extension for validating passwords
const passwordExtension = {
  type: "password",
  base: Joi.string()
    .min(8)
    .max(50)
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).*$/)
    //     "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).*$",

    .messages({
      // eslint-disable-next-line @typescript-eslint/naming-convention
      "string.pattern.base":
        "{{#label}} must contain at least one uppercase letter, one lowercase letter, one digit",
    }),
};

// Extend Joi with the custom extensions
interface ExtendedJoi extends Joi.Root {
  email(): StringSchema<string>;
  contactNumber(): StringSchema<string>;
  password(): StringSchema<string>;
}

const joi = Joi.extend(
  contactNumberExtension,
  emailExtension,
  passwordExtension,
) as ExtendedJoi;
joi.string().required();
export default joi as ExtendedJoi;
