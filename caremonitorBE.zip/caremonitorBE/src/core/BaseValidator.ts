import { Validator, ValidationError } from "./Validator";
import { BadRequestError } from "./ApiError";
import Joi from "joi";

export class JoiBasedValidator<T> implements Validator<T> {
  constructor(private readonly schema: Joi.ObjectSchema<T>) {}
  async validate(obj: unknown): Promise<T> {
    try {
      return await this.schema.validateAsync(obj, { abortEarly: false });
    } catch (error) {
      const details = (error as Joi.ValidationError).details.map(
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        ({ context, type, ...rest }) => rest as ValidationError,
      );
      throw BadRequestError.of(details);
    }
  }
}
