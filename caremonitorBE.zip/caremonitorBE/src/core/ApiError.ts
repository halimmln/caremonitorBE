import { Response } from "express";
import { environment } from "../config";
import {
  AuthFailureResponse,
  AccessTokenErrorResponse,
  InternalErrorResponse,
  NotFoundResponse,
  BadRequestResponse,
  ForbiddenResponse,
  TooManyRequestResponse,
} from "./ApiResponse";
import { ValidationError } from "./Validator";

export enum ErrorType {
  badToken = "BadTokenError",
  tokenExpired = "TokenExpiredError",
  unauthorized = "AuthFailureError",
  accessToken = "AccessTokenError",
  internal = "InternalError",
  notFound = "NotFoundError",
  noEntry = "NoEntryError",
  noData = "NoDataError",
  badRequest = "BadRequestError",
  forbidden = "ForbiddenError",
  tooManyRequests = "TooManyRequests",
}

export abstract class ApiError extends Error {
  constructor(
    public type: ErrorType,
    public message: string = "error",
  ) {
    super(type);
  }

  public static handle(err: ApiError, res: Response): Response {
    switch (err.type) {
      case ErrorType.badToken:
      case ErrorType.tokenExpired:
      case ErrorType.unauthorized:
        return new AuthFailureResponse(err.message).send(res);
      case ErrorType.accessToken:
        return new AccessTokenErrorResponse(err.message).send(res);
      case ErrorType.internal:
        return new InternalErrorResponse(err.message).send(res);
      case ErrorType.notFound:
      case ErrorType.noEntry:
      case ErrorType.noData:
        return new NotFoundResponse(err.message).send(res);
      case ErrorType.badRequest:
        const data = err instanceof BadRequestError ? err.data : undefined;
        return new BadRequestResponse(err.message, data).send(res);
      case ErrorType.forbidden:
        return new ForbiddenResponse(err.message).send(res);
      case ErrorType.tooManyRequests:
        return new TooManyRequestResponse(err.message).send(res);
      default: {
        let message = err.message;
        // Do not send failure message in production as it may send sensitive data
        if (environment === "production") message = "Something wrong happened.";
        return new InternalErrorResponse(message).send(res);
      }
    }
  }
}

export class AuthFailureError extends ApiError {
  constructor(message = "Invalid Credentials") {
    super(ErrorType.unauthorized, message);
  }
}

export class InternalError extends ApiError {
  constructor(message = "Internal error") {
    super(ErrorType.internal, message);
  }
}

export class BadRequestError extends ApiError {
  constructor(
    message = "Bad Request",
    public data: ValidationError[] | undefined = undefined,
  ) {
    super(ErrorType.badRequest, message);
  }

  public static of(data: ValidationError[]): BadRequestError {
    return new BadRequestError("Bad Request", data);
  }
}

export class NotFoundError extends ApiError {
  constructor(message = "Not Found") {
    super(ErrorType.notFound, message);
  }
}

export class ForbiddenError extends ApiError {
  constructor(message = "Permission denied") {
    super(ErrorType.forbidden, message);
  }
}

export class NoEntryError extends ApiError {
  constructor(message = "Entry don't exists") {
    super(ErrorType.noEntry, message);
  }
}

export class BadTokenError extends ApiError {
  constructor(message = "Token is not valid") {
    super(ErrorType.badToken, message);
  }
}

export class TokenExpiredError extends ApiError {
  constructor(message = "Token is expired") {
    super(ErrorType.tokenExpired, message);
  }
}

export class NoDataError extends ApiError {
  constructor(message = "No data available") {
    super(ErrorType.noData, message);
  }
}
export class TooManyRequestError extends ApiError {
  constructor(
    public data: ValidationError[] | undefined = undefined,
    message = "Too many requests. please try after sometime",
  ) {
    super(ErrorType.tooManyRequests, message);
  }
}
