import express, { Router } from "express";
import { AppDependencyInjector } from "./";
import { asyncHandler } from "../helpers";
import { AuthController } from "../Auth/AuthController";
import {  ItemController } from "../Item/ItemController";
import multer from "multer";

const storage = multer.memoryStorage();
const upload = multer({ storage });

export default function apiRoutes(diContainer: AppDependencyInjector): Router {
  const itemController = diContainer.injectClass(ItemController);
  const authController = diContainer.injectClass(AuthController);
  const router = express.Router({ mergeParams: true });

  // ---Auth---
  router
    .route("/token")
    .post(asyncHandler(authController.login.bind(authController)));

  router
    .route("/logout")
    .post(asyncHandler(authController.logout.bind(authController)));
  router
    .route("/setPassword")
    .post(asyncHandler(authController.logout.bind(authController)));
 
  router
    .route("/refresh")
    .post(asyncHandler(authController.refresh.bind(authController)));

 
  // ---Bank---
  router
    .route("/item")
    .post(upload.single("file"),asyncHandler(itemController.createItem.bind(itemController)));

  router
    .route("/item")
    .get(asyncHandler(itemController.getAllItems.bind(itemController)));


  return router;
}
