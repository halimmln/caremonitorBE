import { createInjector, Scope } from "typed-inject";
import { kyselyDb } from "../db/database";
import { AdminUserRepo } from "../Item/AdminUserRepo";
import logger from "../core/Logger";
import { ItemRepo } from "../Item/ItemRepo";
import { AuthService } from "../Auth/AuthService";
export type AppDependencyInjector = ReturnType<typeof configureDI>;
import {
  dbHost as host,
  dbName as database,
  dbUser as user,
  dbPassword as password,
  dbPort as port,
} from "../config";
import { DbConfig } from "../db";
import { AdminTokenRepo } from "../Auth/AdminTokenRepo";
const dbConfig: DbConfig = { host, database, user, password, port };
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export default function configureDI() {
  const container = createInjector()
    .provideValue("logger", logger)
    .provideValue("dbConfig", dbConfig)
    .provideFactory("db", () => kyselyDb(dbConfig), Scope.Singleton)

    .provideClass("itemRepo", ItemRepo)

    .provideClass("adminUserRepo", AdminUserRepo)
    .provideClass("adminTokenRepo", AdminTokenRepo)

    .provideClass("authService", AuthService);
  return container;
}
