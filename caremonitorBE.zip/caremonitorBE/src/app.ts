import express, { Request, Response, NextFunction } from "express";
import * as UAParser from "ua-parser-js";

declare module "express" {
  interface Request {
    auditDetails?: {
      ip: string;
      browser: {
        name: string;
        version: string;
      };
      timestamp: string;
    };
  }
}
import { environment, jwtPrivateKey } from "./config";
import Logger from "./core/Logger";
import {
  ApiError,
  BadTokenError,
  ErrorType,
  ForbiddenError,
  InternalError,
  NotFoundError,
  TokenExpiredError,
} from "./core/ApiError";
import cors from "cors";
import configureDI from "./configuration/index";
import apiRoutes from "./configuration/router";
import cookieParser from "cookie-parser";
import logger from "./core/Logger";
import jwt from "jsonwebtoken";
import { IsRevoked, UnauthorizedError, expressjwt } from "express-jwt";
import {
  TokenExpiredError as JWTTokenExpiredError,
  JwtPayload,
} from "jsonwebtoken";
import { UUID } from "crypto";
import requestIp from "request-ip";

process.on("uncaughtException", (e) => Logger.error(e));

const app = express();

const isLocal = environment === "local";
if (isLocal) {
  app.use(
    cors({
      origin: "http://localhost:4200",
      credentials: true,
    }),
  );
}

export const container = configureDI();

const adminTokenRepo = container.resolve("adminTokenRepo");

const revokedTokenChecker: IsRevoked = async (_req, token) => {
  
    const jwtPayload = token?.payload as JwtPayload;
    const tokenState = await adminTokenRepo.findById(jwtPayload.jti! as UUID);
    return !tokenState;
  
};

const deleteTokenOnExpiry = async (req: Request, err: UnauthorizedError) => {
  
  if (err.inner instanceof JWTTokenExpiredError) {
    const token = req.headers.authorization?.split(" ").at(1);
    const payload = jwt.verify(token!, jwtPrivateKey, {
      ignoreExpiration: true,
    }) as jwt.JwtPayload;
    
      await adminTokenRepo.deleteToken(payload.jti! as UUID);
    
    throw new TokenExpiredError();
  }
};
// Middleware to capture IP and browser details
const addRequestDetails = (
  req: Request,
  _res: Response,
  next: NextFunction,
) => {
  const ipAddress = requestIp.getClientIp(req);
  const userAgent = req.get("User-Agent") || "";
  const parser = new UAParser.UAParser(userAgent);

  const browser = parser.getBrowser();

  req.auditDetails = {
    ip: ipAddress || "Unknown IP",
    browser: {
      name: browser.name || "Unknown Browser",
      version: browser.version || "Unknown Version",
    },
    timestamp: new Date().toISOString(), // Add a timestamp
  };

  next();
};

// Use the middleware globally
app.use(addRequestDetails);
app.use(express.static(__dirname + "/public"));
app.use(express.json());
app.use(cookieParser());

app.use(
  "/api",
  expressjwt({
    secret: jwtPrivateKey,
    algorithms: ["HS256"],
    requestProperty: "auth",
    onExpired: deleteTokenOnExpiry,
    isRevoked: revokedTokenChecker,
  }).unless({
    path: [
      "/api/token",
      "/api/refresh",
    ],
  }),
  apiRoutes(container),
);

app.use((_req, _res, next: NextFunction) => {
  if (_req.path.includes("api")) return next(new NotFoundError());
  else _res.sendFile("index.html", { root: __dirname + "/public" });
});

// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
  if (err instanceof UnauthorizedError) {
    switch (err.code) {
      case "revoked_token": {
        err = new TokenExpiredError();
        break;
      }
      case "credentials_required": {
        err = new ForbiddenError();
        break;
      }
      case "invalid_token":
      case "credentials_bad_format": {
        err = new BadTokenError();
        break;
      }
    }
  }

  if (err instanceof ApiError) {
    ApiError.handle(err, res);
    if (err.type === ErrorType.internal)
      logger.error(
        `500 - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`,
        err,
      );
  } else {
    logger.error(
      `500 - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`,
    );
    logger.error("🔥", err);
    if (environment != "production") {
      return res.status(500).send({ ...err, message: err.message });
    }
    ApiError.handle(new InternalError(), res);
  }
});

export default app;
