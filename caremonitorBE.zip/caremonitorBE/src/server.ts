import Logger from "./core/Logger";
import { port } from "./config";
import app, { container } from "./app";
import logger from "./core/Logger";
import { migrateToLatest } from "./db";
app
  .listen(port, async () => {
    const dbConfig = container.resolve("dbConfig");
    await migrateToLatest(dbConfig);
    logger.info(`⚡️ server is running at http://localhost:${port}`);
  })
  .on("error", e => Logger.error(e));
