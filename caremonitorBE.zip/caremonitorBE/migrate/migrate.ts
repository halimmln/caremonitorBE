import { Pool } from "pg";
import { promises as fs } from "fs";
import {
  Kysely,
  Migrator,
  PostgresDialect,
  FileMigrationProvider,
  MigrationResultSet,
} from "kysely";
import path from "path";
import logger from "../src/core/Logger";

function database(): Kysely<unknown> {
  const config = {
    host: process.env.DB_HOST || "localhost",
    database: process.env.DB_NAME || "postgres",
    user: process.env.DB_USER || "postgres",
    password: process.env.DB_PASSWORD || "postgres",
    port: +(process.env.DB_PORT || 5432),
    max: 10,
  };
  return new Kysely<unknown>({
    dialect: new PostgresDialect({ pool: new Pool(config) }),
  });
}
function initMigrator(db: Kysely<unknown>) {
  return new Migrator({
    db,
    provider: new FileMigrationProvider({
      fs,
      path,
      // This needs to be an absolute path.
      migrationFolder: path.join(
        __dirname,
        "../src/db/MettarevAdminMigrations",
      ),
    }),
  });
}

export async function migrate(
  how: (migrator: Migrator) => Promise<MigrationResultSet> = (m) =>
    m.migrateToLatest(),
): Promise<void> {
  const db = database();
  const migrator = initMigrator(db);
  const { error, results } = await how(migrator);

  results?.forEach((it) => {
    const direction = `direction(${it.direction == "Up" ? "🔺" : "🔻"})`;
    const status =
      it.status == "Success" ? "✅" : it.status == "Error" ? "❌" : "⏸️";
    const msg = `${it.migrationName} executed in ${direction} ${status}`;
    if (it.status === "Success") console.log(`${msg}`);
    else if (it.status === "Error") console.error(`${msg}`);
  });

  if (error) {
    logger.error("failed to migrate");
    logger.error(error);
    process.exit(1);
  }

  await db.destroy();
}
