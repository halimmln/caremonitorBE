import { migrate } from "./migrate";

migrate(async (m) => m.migrateUp());
