import { migrate } from "./migrate";

migrate();
