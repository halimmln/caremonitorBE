import { NO_MIGRATIONS } from "kysely";
import { migrate } from "./migrate";

async function run() {
  await migrate(async (m) => m.migrateTo(NO_MIGRATIONS));
  await migrate();
}
run();
